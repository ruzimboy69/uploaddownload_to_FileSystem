package uz.pdp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileUploadDownloadAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
